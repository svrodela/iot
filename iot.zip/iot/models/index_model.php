<?php

class Index_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getAllrecords()
	{
		return $this->db->select("SELECT * FROM `Registros` ORDER BY Fecha DESC");
	}
	public function submit_index($data)
	{
		$this->db->insert('Registros', $data);
	}
	}
	?>