CREATE TABLE registros (
IDRegistro INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Usuario Char(50),
Fecha TIMESTAMP,
Tem Float NULL,
Luz Float NULL,
Hum Float NULL
);
